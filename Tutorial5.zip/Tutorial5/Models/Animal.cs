﻿namespace Tutorial5.Models;

public class Animal
{
    public int IdAnimal { get; set; }
    public string Name { get; set; }
}